
USE Blue_Sky_Online_Consumer_Electronics_Retailer;


CREATE TABLE CUSTPreference (
    Customer_Code_Id NVARCHAR(50) NOT NULL,
    Payment_type_Id int NOT NULL,
    Channel_Code varchar(50) NOT NULL,
    DateKey INT NOT NULL,
    Total_Transaction DECIMAL(10,0) NOT NULL
)


CREATE TABLE ProfitableCustomer (
    Customer_Code_Id NVARCHAR(50) PRIMARY KEY NOT NULL,
    DateKey INT NOT NULL,
    Invoice_number NVARCHAR(MAX)  NOT NULL,
    Total_profit NUMERIC NOT NULL,
    RankByProfit NUMERIC NOT NULL
)