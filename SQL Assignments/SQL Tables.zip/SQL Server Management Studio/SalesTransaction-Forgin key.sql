USE Blue_Sky_Online_Consumer_Electronics_Retailer;

ALTER TABLE SalesTransaction
ADD CONSTRAINT fk_SalesTransaction_Customer_Code_Id
FOREIGN KEY (Customer_Code_Id) REFERENCES CustomerDetails(Customer_Code_Id);




ALTER TABLE SalesTransaction
ADD CONSTRAINT fk_SalesTransaction_Payment_type_Id
FOREIGN KEY (Payment_type_Id) REFERENCES PayementData(Payment_type_Id);


ALTER TABLE SalesTransaction
ADD CONSTRAINT fk_SalesTransaction_Channel_code
FOREIGN KEY (Channel_code) REFERENCES Selling_channel(Channel_code);
