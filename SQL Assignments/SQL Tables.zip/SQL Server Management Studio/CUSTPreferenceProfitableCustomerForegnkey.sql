USE Blue_Sky_Online_Consumer_Electronics_Retailer;


ALTER TABLE CUSTPreference
ADD CONSTRAINT fk_CUSTPreference_Customer_Code_Id
FOREIGN KEY (Customer_Code_Id) REFERENCES CustomerDetails(Customer_Code_Id);

ALTER TABLE CUSTPreference
ADD CONSTRAINT fk_CUSTPreference_Payment_type_Id
FOREIGN KEY (Payment_type_Id) REFERENCES PayementData(Payment_type_Id);


ALTER TABLE CUSTPreference
ADD CONSTRAINT fk_CUSTPreference_Channel_Code
FOREIGN KEY (Channel_Code) REFERENCES Selling_channel(Channel_Code);


ALTER TABLE CUSTPreference
ADD CONSTRAINT fk_CUSTPreference_DateKey
FOREIGN KEY (DateKey) REFERENCES DatesTime(DateKey);



ALTER TABLE ProfitableCustomer
ADD CONSTRAINT fk_ProfitableCustomer_Customer_Code_Id
FOREIGN KEY (Customer_Code_Id) REFERENCES CustomerDetails(Customer_Code_Id);

ALTER TABLE ProfitableCustomer
ADD CONSTRAINT fk_ProfitableCustomer_DateKey
FOREIGN KEY (DateKey) REFERENCES DatesTime(DateKey);





