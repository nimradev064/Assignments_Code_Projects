USE Blue_Sky_Online_Consumer_Electronics_Retailer;

LOAD DATA LOCAL INFILE 'DATA/PaymentsData.csv'
INTO TABLE image_data_table
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n';
