USE Blue_Sky_Online_Consumer_Electronics_Retailer;

CREATE TABLE TransactionGroup (
    Customer_Code_Id NVARCHAR(50) NOT NULL,
    DateKey INT NOT NULL,
    Invoice_number NVARCHAR(MAX)  NOT NULL,
    Age_group NVARCHAR(MAX) NOT NULL,
    Income_group NVARCHAR(MAX) NOT NULL,
    Marital_status_group NVARCHAR(MAX) NOT NULL,
    Post_code_group NVARCHAR(MAX) NOT NULL,
    City_group VARCHAR(MAX) NOT NULL,
    Total_Transaction DECIMAL(10,0) NOT NULL

);


CREATE TABLE DatesTime (
    DateKey int PRIMARY KEY NOT NULL,
    Full_date DATE NOT NULL,
    Date_name DATE NOT NULL,
    Day_of_week INT NOT NULL,
    Day_name_of_week VARCHAR(50) NOT NULL,
    Day_of_month INT NOT NULL,
    Day_of_year INT NOT NULL,
    Week_day_weekend VARCHAR(MAX) NOT NULL CHECK (Week_day_weekend IN('Weekday', 'Weekend')),
    Week_of_year INT NOT NULL,
    Month_name VARCHAR(50) NOT NULL,
    Month_of_year INT NOT NULL,
    Is_last_day_of_month VARCHAR(50) NOT NULL,
    Calendar_quarter INT NOT NULL,
    Calendar_year INT NOT NULL,
    Calendar_year_month NVARCHAR(50) NOT NULL,
    Calendar_year_qtr NVARCHAR(50) NOT NULL,
    Fiscal_month_of_year INT NOT NULL,
    Fiscal_quarter INT NOT NULL,
    Fiscal_year INT NOT NULL,
    Fiscal_year_month NVARCHAR(50) NOT NULL,
    Fiscal_year_qtr NVARCHAR(50) NOT NULL
);

CREATE TABLE CustomerDetails (
    Customer_Code_Id NVARCHAR(50) PRIMARY KEY NOT NULL,
    First_Name VARCHAR (MAX) NOT NULL,
	Last_Name VARCHAR (MAX) NOT NULL,
	Marital_Status VARCHAR(MAX) NOT NULL CHECK (Marital_Status IN('Married','Single', 'Divorced', 'Widowed')),
    Birth_Date DATE NOT NULL,
    Gender VARCHAR(50) NOT NULL CHECK (Gender IN('Male' , 'Female', 'Other')),
    Post_code NVARCHAR (MAX) NOT NULL,
    City VARCHAR (MAX) NOT NULL,
    Income DECIMAL (18,10) NOT NULL
);

CREATE TABLE SalesTransaction (
    Invoice_number NVARCHAR(MAX) NOT NULL,
    Customer_Code_Id NVARCHAR(50) NOT NULL,
    Payment_type_Id int NOT NULL,
    Channel_Code varchar(50) NOT NULL,
    DateKey date NOT NULL,
    Total_Cost decimal(18,10) NOT NULL,
    Total_Retail_Price decimal(18,10) NOT NULL,
);

CREATE TABLE Selling_channel(

    Channel_code VARCHAR(50) PRIMARY KEY NOT NULL,
    Channel_name VARCHAR(MAX) NOT NULL,
    Commission_rate DECIMAL(18,10) NOT NULL
);

CREATE TABLE PayementData(
    Payment_type_Id INT PRIMARY KEY NOT NULL,
    Payement_type_id_name VARCHAR(MAX) NOT NULL,
);