USE Blue_Sky_Online_Consumer_Electronics_Retailer;

ALTER TABLE TransactionGroup
ADD CONSTRAINT fk_TransactionGroup_Customer_Code_Id
FOREIGN KEY (Customer_Code_Id) REFERENCES CustomerDetails(Customer_Code_Id);


ALTER TABLE TransactionGroup
ADD CONSTRAINT fk_TransactionGroup_DateKey
FOREIGN KEY (DateKey) REFERENCES DatesTime(DateKey);



